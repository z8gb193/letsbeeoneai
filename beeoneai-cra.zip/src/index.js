import React from 'react';
import ReactDOM from 'react-dom/client';
import BeeOneAIChat from './BeeOneAIChat';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BeeOneAIChat />
  </React.StrictMode>
);
